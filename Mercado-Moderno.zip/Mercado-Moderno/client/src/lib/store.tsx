import React, { createContext, useContext, useState, useEffect } from "react";

// Mock Data Types
export type UserType = "buyer" | "seller";

export interface User {
  id: string;
  name: string;
  email: string;
  type: UserType;
  cpf?: string; // Only for sellers
}

export interface Product {
  id: string;
  sellerId: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

export interface CartItem extends Product {
  quantity: number;
}

interface MarketContextType {
  user: User | null;
  products: Product[];
  cart: CartItem[];
  login: (email: string, type: UserType, name: string, cpf?: string) => void;
  logout: () => void;
  addProduct: (product: Omit<Product, "id">) => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

// Mock Initial Products
const INITIAL_PRODUCTS: Product[] = [
  {
    id: "1",
    sellerId: "seller1",
    name: "Smartphone Galaxy S23 Ultra",
    description: "The ultimate smartphone experience with 200MP camera and S-Pen.",
    price: 5999.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "2",
    sellerId: "seller1",
    name: "Sony WH-1000XM5 Headphones",
    description: "Industry leading noise canceling headphones.",
    price: 1899.00,
    category: "Audio",
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "3",
    sellerId: "seller2",
    name: "MacBook Air M2",
    description: "Supercharged by M2. Thin, light, and powerful.",
    price: 8499.00,
    category: "Computers",
    image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "4",
    sellerId: "seller2",
    name: "Mechanical Keyboard Keychron K2",
    description: "Tactile mechanical keyboard for professionals.",
    price: 650.00,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1595225476474-87563907a212?auto=format&fit=crop&q=80&w=800",
  },
];

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);

  const login = (email: string, type: UserType, name: string, cpf?: string) => {
    setUser({
      id: Math.random().toString(36).substr(2, 9),
      email,
      name,
      type,
      cpf,
    });
  };

  const logout = () => {
    setUser(null);
    setCart([]);
  };

  const addProduct = (productData: Omit<Product, "id">) => {
    const newProduct = {
      ...productData,
      id: Math.random().toString(36).substr(2, 9),
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== productId));
  };

  const clearCart = () => setCart([]);

  return (
    <MarketContext.Provider
      value={{
        user,
        products,
        cart,
        login,
        logout,
        addProduct,
        addToCart,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </MarketContext.Provider>
  );
}

export function useMarket() {
  const context = useContext(MarketContext);
  if (context === undefined) {
    throw new Error("useMarket must be used within a MarketProvider");
  }
  return context;
}
