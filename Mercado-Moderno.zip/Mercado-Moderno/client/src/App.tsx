import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import AuthPage from "@/pages/auth";
import ProductDetails from "@/pages/product-details";
import SellerDashboard from "@/pages/seller-dashboard";
import Checkout from "@/pages/checkout";
import { MarketProvider } from "@/lib/store";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/product/:id" component={ProductDetails} />
      <Route path="/dashboard" component={SellerDashboard} />
      <Route path="/checkout" component={Checkout} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <MarketProvider>
        <Router />
        <Toaster />
      </MarketProvider>
    </QueryClientProvider>
  );
}

export default App;
