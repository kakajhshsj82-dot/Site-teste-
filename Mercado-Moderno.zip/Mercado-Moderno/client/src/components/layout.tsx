import { Link, useLocation } from "wouter";
import { useMarket } from "@/lib/store";
import { ShoppingCart, User, Search, Store, LogOut, Menu } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, cart, logout } = useMarket();
  const [location, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would filter or redirect
    console.log("Searching for:", search);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background font-sans">
      <header className="sticky top-0 z-50 w-full border-b bg-primary text-primary-foreground shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2 font-heading font-bold text-xl md:text-2xl hover:opacity-90 transition-opacity">
            <Store className="h-6 w-6" />
            <span>MarketPlace</span>
          </Link>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-lg mx-4 relative">
            <Input 
              placeholder="Buscar produtos, marcas e muito mais..." 
              className="w-full bg-white text-foreground pl-4 pr-10 rounded-full border-0 focus-visible:ring-2 focus-visible:ring-secondary"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors">
              <Search className="h-5 w-5" />
            </button>
          </form>

          <div className="flex items-center gap-2 md:gap-4">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2 text-primary-foreground hover:text-white hover:bg-white/10">
                    <User className="h-5 w-5" />
                    <span className="hidden md:inline font-medium">
                      Olá, {user.name.split(" ")[0]}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Minha Conta ({user.type === 'seller' ? 'Vendedor' : 'Comprador'})</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {user.type === "seller" && (
                    <DropdownMenuItem onClick={() => setLocation("/dashboard")}>
                      Painel do Vendedor
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button variant="ghost" className="text-primary-foreground hover:text-white hover:bg-white/10">
                  Entrar
                </Button>
              </Link>
            )}

            <Link href="/checkout">
              <Button variant="ghost" className="relative text-primary-foreground hover:text-white hover:bg-white/10">
                <ShoppingCart className="h-6 w-6" />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-secondary text-secondary-foreground text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full animate-in zoom-in">
                    {cart.reduce((acc, item) => acc + item.quantity, 0)}
                  </span>
                )}
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Mobile Search Bar */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={handleSearch} className="relative">
            <Input 
              placeholder="Buscar no MarketPlace" 
              className="w-full bg-white text-foreground pl-4 pr-10 rounded-full border-0 h-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
              <Search className="h-4 w-4" />
            </button>
          </form>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="border-t bg-white mt-auto">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>© 2024 MarketPlace MVP. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
