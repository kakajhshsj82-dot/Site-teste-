import { Link } from "wouter";
import { Product } from "@/lib/store";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import { ShoppingCart } from "lucide-react";
import { useMarket } from "@/lib/store";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useMarket();

  return (
    <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-0 shadow-sm bg-white h-full flex flex-col">
      <Link href={`/product/${product.id}`} className="cursor-pointer flex-1">
        <div className="aspect-[4/3] overflow-hidden bg-gray-100 relative">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1 font-semibold">{product.category}</p>
          <h3 className="font-heading font-medium text-lg text-foreground line-clamp-2 leading-tight mb-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <div className="mt-2">
            <span className="text-2xl font-bold text-foreground">
              {formatCurrency(product.price)}
            </span>
            <p className="text-xs text-green-600 font-medium mt-1">
              10x {formatCurrency(product.price / 10)} sem juros
            </p>
          </div>
        </CardContent>
      </Link>
      <CardFooter className="p-4 pt-0 mt-auto">
        <Button 
          className="w-full gap-2 font-medium" 
          onClick={() => addToCart(product)}
        >
          <ShoppingCart className="h-4 w-4" />
          Adicionar
        </Button>
      </CardFooter>
    </Card>
  );
}
