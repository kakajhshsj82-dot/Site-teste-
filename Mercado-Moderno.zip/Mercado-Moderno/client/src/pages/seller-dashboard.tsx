import { Layout } from "@/components/layout";
import { useMarket } from "@/lib/store";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Plus, Package, DollarSign, Image as ImageIcon } from "lucide-react";

const productSchema = z.object({
  name: z.string().min(5, "Nome muito curto"),
  price: z.coerce.number().min(1, "Preço deve ser maior que 0"),
  description: z.string().min(10, "Descrição muito curta"),
  image: z.string().url("URL de imagem inválida"),
  category: z.string().min(1, "Categoria obrigatória"),
});

type ProductForm = z.infer<typeof productSchema>;

export default function SellerDashboard() {
  const { user, products, addProduct } = useMarket();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<ProductForm>({
    resolver: zodResolver(productSchema),
  });

  useEffect(() => {
    if (!user || user.type !== "seller") {
      setLocation("/auth");
    }
  }, [user, setLocation]);

  const onSubmit = (data: ProductForm) => {
    if (user?.id) {
      addProduct({ ...data, sellerId: user.id });
      toast({ title: "Sucesso!", description: "Produto cadastrado com sucesso." });
      form.reset();
    }
  };

  if (!user) return null;

  return (
    <Layout>
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Sidebar / Stats */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Painel do Vendedor</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-6">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                  {user.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold">{user.name}</h3>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                  <p className="text-xs text-muted-foreground mt-1">CPF: {user.cpf}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="p-4 bg-muted rounded-lg flex justify-between items-center">
                  <span className="text-sm font-medium">Produtos Ativos</span>
                  <span className="font-bold text-lg">{products.filter(p => p.sellerId === user.id || p.sellerId === "seller1").length}</span>
                </div>
                <div className="p-4 bg-muted rounded-lg flex justify-between items-center">
                  <span className="text-sm font-medium">Vendas (Mês)</span>
                  <span className="font-bold text-lg">12</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Add Product Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Novo Anúncio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="prod-name">Título do Anúncio</Label>
                  <Input id="prod-name" placeholder="Ex: iPhone 14 Pro Max 256GB" {...form.register("name")} />
                  {form.formState.errors.name && <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="prod-price">Preço (R$)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input id="prod-price" type="number" step="0.01" className="pl-9" {...form.register("price")} />
                    </div>
                    {form.formState.errors.price && <p className="text-xs text-destructive">{form.formState.errors.price.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="prod-cat">Categoria</Label>
                    <Input id="prod-cat" placeholder="Ex: Celulares" {...form.register("category")} />
                    {form.formState.errors.category && <p className="text-xs text-destructive">{form.formState.errors.category.message}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="prod-img">URL da Imagem</Label>
                  <div className="relative">
                    <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="prod-img" placeholder="https://..." className="pl-9" {...form.register("image")} />
                  </div>
                  {form.formState.errors.image && <p className="text-xs text-destructive">{form.formState.errors.image.message}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="prod-desc">Descrição</Label>
                  <Textarea id="prod-desc" rows={5} placeholder="Descreva os detalhes do seu produto..." {...form.register("description")} />
                  {form.formState.errors.description && <p className="text-xs text-destructive">{form.formState.errors.description.message}</p>}
                </div>

                <Button type="submit" className="w-full font-bold">Publicar Anúncio</Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
