import { Layout } from "@/components/layout";
import { useMarket } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";
import { useLocation } from "wouter";
import { Trash2, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Checkout() {
  const { cart, removeFromCart, clearCart, user } = useMarket();
  const [, setLocation] = useLocation();
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();

  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handleBuy = () => {
    if (!user) {
      toast({ title: "Faça login", description: "Você precisa entrar para finalizar a compra." });
      setLocation("/auth");
      return;
    }
    setIsSuccess(true);
    clearCart();
  };

  if (isSuccess) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center py-20 animate-in zoom-in duration-500">
          <div className="bg-green-100 p-6 rounded-full mb-6">
            <CheckCircle2 className="h-16 w-16 text-green-600" />
          </div>
          <h1 className="text-3xl font-heading font-bold mb-2">Compra realizada com sucesso!</h1>
          <p className="text-muted-foreground mb-8 text-center max-w-md">
            Obrigado pela sua compra. O vendedor já foi notificado e enviará seu produto em breve.
          </p>
          <Button onClick={() => { setIsSuccess(false); setLocation("/"); }} size="lg">
            Voltar para a Loja
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <h1 className="text-2xl font-heading font-bold mb-6">Carrinho de Compras</h1>
      
      {cart.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border shadow-sm">
          <p className="text-muted-foreground mb-4">Seu carrinho está vazio.</p>
          <Button onClick={() => setLocation("/")}>Ver Ofertas</Button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <Card key={item.id} className="flex flex-row items-center p-4 gap-4">
                <div className="h-24 w-24 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                  <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm md:text-base line-clamp-2">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">Quantidade: {item.quantity}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">{formatCurrency(item.price * item.quantity)}</p>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 mt-2 h-8" onClick={() => removeFromCart(item.id)}>
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Remover</span>
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Produtos ({cart.length})</span>
                  <span>{formatCurrency(total)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Frete</span>
                  <span className="text-green-600 font-medium">Grátis</span>
                </div>
                <div className="h-px bg-border my-2" />
                <div className="flex justify-between text-xl font-bold">
                  <span>Total</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full font-bold h-12 text-lg" onClick={handleBuy}>
                  Confirmar Compra
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </Layout>
  );
}
