import { useParams } from "wouter";
import { Layout } from "@/components/layout";
import { useMarket } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import { ShieldCheck, Truck, ShoppingCart, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetails() {
  const { id } = useParams();
  const { products, addToCart } = useMarket();
  const { toast } = useToast();

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold">Produto não encontrado</h2>
        </div>
      </Layout>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Adicionado ao carrinho",
      description: `${product.name} foi adicionado.`,
    });
  };

  return (
    <Layout>
      <div className="bg-white rounded-xl shadow-sm border p-6 md:p-8">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Image Gallery Mock */}
          <div className="space-y-4">
            <div className="aspect-[4/3] rounded-lg overflow-hidden border bg-gray-50">
              <img src={product.image} alt={product.name} className="w-full h-full object-contain p-4" />
            </div>
            <div className="grid grid-cols-4 gap-2">
               {[1,2,3,4].map(i => (
                 <div key={i} className={`aspect-square rounded border cursor-pointer hover:border-primary ${i === 1 ? 'border-primary ring-1 ring-primary' : 'border-gray-200'}`}>
                    <img src={product.image} alt="Thumbnail" className="w-full h-full object-contain p-1" />
                 </div>
               ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <span className="text-sm text-muted-foreground">Novo  |  +100 vendidos</span>
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-gray-900 mt-2">{product.name}</h1>
            </div>

            <div className="space-y-1">
              <h2 className="text-4xl font-light text-gray-900">{formatCurrency(product.price)}</h2>
              <p className="text-green-600 font-medium">em 10x {formatCurrency(product.price / 10)} sem juros</p>
              <p className="text-sm text-blue-600 font-medium cursor-pointer hover:underline">Ver os meios de pagamento</p>
            </div>

            <div className="space-y-3 pt-4">
              <div className="flex items-start gap-3">
                <Truck className="text-green-600 mt-1" />
                <div>
                  <p className="font-semibold text-green-600">Frete Grátis</p>
                  <p className="text-sm text-muted-foreground">Chegará grátis entre amanhã e terça-feira</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="text-muted-foreground mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground"><span className="font-semibold text-gray-700">Compra Garantida</span>, receba o produto que está esperando ou devolvemos o dinheiro.</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3 pt-6">
              <Button size="lg" className="w-full text-lg font-semibold h-14" onClick={handleAddToCart}>
                Comprar agora
              </Button>
              <Button size="lg" variant="secondary" className="w-full text-lg font-semibold h-14 bg-blue-50 text-blue-600 hover:bg-blue-100 border-0" onClick={handleAddToCart}>
                Adicionar ao carrinho
              </Button>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mt-12 pt-8 border-t">
          <h3 className="text-xl font-heading font-bold mb-4">Descrição</h3>
          <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">
            {product.description}
            {`\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.`}
          </p>
        </div>
      </div>
    </Layout>
  );
}
