import { Layout } from "@/components/layout";
import { ProductCard } from "@/components/product-card";
import { useMarket } from "@/lib/store";
import { PackageOpen } from "lucide-react";

export default function Home() {
  const { products } = useMarket();

  return (
    <Layout>
      <div className="space-y-8">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-blue-600 rounded-2xl p-6 md:p-12 text-white shadow-xl overflow-hidden relative">
          <div className="relative z-10 max-w-2xl">
            <h1 className="text-3xl md:text-5xl font-heading font-bold mb-4 leading-tight">
              As melhores ofertas <br/>
              <span className="text-secondary">você encontra aqui.</span>
            </h1>
            <p className="text-blue-100 text-lg mb-8 max-w-md">
              Eletrônicos, moda, casa e muito mais com entrega rápida e segurança garantida.
            </p>
          </div>
          <div className="absolute right-0 bottom-0 opacity-10 md:opacity-20 translate-x-1/4 translate-y-1/4">
            <PackageOpen size={400} />
          </div>
        </section>

        {/* Categories (Mock) */}
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {["Ofertas do Dia", "Celulares", "Informática", "Games", "Casa", "Moda"].map((cat) => (
            <button key={cat} className="flex-shrink-0 px-6 py-3 bg-white rounded-full shadow-sm hover:shadow-md hover:text-primary font-medium transition-all whitespace-nowrap border border-transparent hover:border-primary/20">
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-heading font-bold text-gray-800">
              Baseado no seu interesse
            </h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
}
