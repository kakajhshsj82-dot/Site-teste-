import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMarket } from "@/lib/store";
import { useLocation } from "wouter";
import { validateCPF, formatCPF } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// Schemas
const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
});

const registerSchema = z.object({
  name: z.string().min(3, "Nome muito curto"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
  type: z.enum(["buyer", "seller"]),
  cpf: z.string().optional(),
}).refine((data) => {
  if (data.type === "seller") {
    if (!data.cpf) return false;
    return validateCPF(data.cpf);
  }
  return true;
}, {
  message: "CPF inválido ou obrigatório para vendedores",
  path: ["cpf"],
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { login } = useMarket();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      type: "buyer",
    },
  });

  const onLogin = (data: LoginForm) => {
    // Simulating login
    login(data.email, "buyer", "Usuário Teste"); // Default fallback login
    toast({ title: "Bem-vindo de volta!", description: "Login realizado com sucesso." });
    setLocation("/");
  };

  const onRegister = (data: RegisterForm) => {
    login(data.email, data.type, data.name, data.cpf);
    toast({ title: "Conta criada!", description: `Bem-vindo, ${data.name}!` });
    setLocation(data.type === "seller" ? "/dashboard" : "/");
  };

  const userType = registerForm.watch("type");

  return (
    <Layout>
      <div className="max-w-md mx-auto mt-12">
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="login">Entrar</TabsTrigger>
            <TabsTrigger value="register">Criar Conta</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <Card>
              <CardHeader>
                <CardTitle>Acesse sua conta</CardTitle>
                <CardDescription>Entre para comprar ou vender produtos.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <Input id="login-email" type="email" {...loginForm.register("email")} />
                    {loginForm.formState.errors.email && (
                      <p className="text-xs text-destructive">{loginForm.formState.errors.email.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="login-pass">Senha</Label>
                    <Input id="login-pass" type="password" {...loginForm.register("password")} />
                    {loginForm.formState.errors.password && (
                      <p className="text-xs text-destructive">{loginForm.formState.errors.password.message}</p>
                    )}
                  </div>
                  <Button type="submit" className="w-full font-bold">Entrar</Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle>Crie sua conta</CardTitle>
                <CardDescription>Junte-se à nossa comunidade de compradores e vendedores.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Eu quero:</Label>
                    <RadioGroup 
                      onValueChange={(val) => registerForm.setValue("type", val as "buyer" | "seller")}
                      defaultValue="buyer"
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted w-1/2">
                        <RadioGroupItem value="buyer" id="r-buyer" />
                        <Label htmlFor="r-buyer" className="cursor-pointer">Comprar</Label>
                      </div>
                      <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted w-1/2">
                        <RadioGroupItem value="seller" id="r-seller" />
                        <Label htmlFor="r-seller" className="cursor-pointer">Vender</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reg-name">Nome Completo</Label>
                    <Input id="reg-name" {...registerForm.register("name")} />
                    {registerForm.formState.errors.name && (
                      <p className="text-xs text-destructive">{registerForm.formState.errors.name.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reg-email">Email</Label>
                    <Input id="reg-email" type="email" {...registerForm.register("email")} />
                    {registerForm.formState.errors.email && (
                      <p className="text-xs text-destructive">{registerForm.formState.errors.email.message}</p>
                    )}
                  </div>

                  {userType === "seller" && (
                    <div className="space-y-2 animate-in slide-in-from-top-2 fade-in">
                      <Label htmlFor="reg-cpf">CPF (Apenas números)</Label>
                      <Input 
                        id="reg-cpf" 
                        placeholder="000.000.000-00" 
                        {...registerForm.register("cpf")} 
                        onChange={(e) => {
                          const formatted = formatCPF(e.target.value);
                          e.target.value = formatted;
                          registerForm.setValue("cpf", formatted);
                        }}
                      />
                      {registerForm.formState.errors.cpf && (
                        <p className="text-xs text-destructive">{registerForm.formState.errors.cpf.message}</p>
                      )}
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="reg-pass">Senha</Label>
                    <Input id="reg-pass" type="password" {...registerForm.register("password")} />
                    {registerForm.formState.errors.password && (
                      <p className="text-xs text-destructive">{registerForm.formState.errors.password.message}</p>
                    )}
                  </div>

                  <Button type="submit" className="w-full font-bold">Cadastrar</Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
